import React from 'react';
import './App.css';
import useModal from './components/useModal';
import 'bootstrap/dist/css/bootstrap.min.css';
import Content from './components/content';



const App = () => {
  const {isShowing, toggle} = useModal();
  return (
    <div className="App">

        
        <Content/>
      
      {/* <button className="button-default" onClick={toggle}>Show Modal</button>

      <Modal
        isShowing={isShowing}
        hide={toggle}
      /> */}
    </div>
  );
};

export default App;






















// import React, { Component } from 'react';
// import StudentList from './components/Studentlist';
// import StudentDetails from './components/StudentDetails';
// import Clock from './components/Clock';
// import FormDemo from './components/FormDemo';
// import ApiDemo from './components/ApiDemo';


// // const App = () => {
// //     return (
// //         <div>
// //             <h1>Welcome to React</h1>
// //         </div>
// //     );
// // }

// class App extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             students: [
//                 { id: 101, name: 'First', cgpa: 3.8 },
//                 { id: 102, name: 'Second', cgpa: 2.6 },
//                 { id: 103, name: 'Third', cgpa: 3.0 },
//                 { id: 104, name: 'Fourth', cgpa: 3.3 },
//                 { id: 105, name: 'Fifth', cgpa: 3.7 }
//             ]
//         };

//         this.selectedStudent = null;
//     }

//     componentDidUpdate() {
//         console.log('After update');
//         console.log(this.state.students);
//     }

//     deleteStudent = id => {
//         console.log('Before setState');
//         console.log(this.state.students);
//         this.setState({
//             students: this.state.students.filter(s => s.id !== id)
//         });
//     }

//     selectStudent = id => {
//         this.selectedStudent = this.state.students.filter(
//             s => s.id === id
//         )[0];
//         this.forceUpdate();
//     }

//     render() {
//         return (
//             <div>
//             <h3 className="mb-5">Student List</h3>
//             <div className="row">
//                     <div className="col">
//                         {/* <StudentList studentlist={this.state.students}
//                             deleteStudent={this.deleteStudent}
//                             onSelectStudent={this.selectStudent} />
//                     </div>
//                     <div className="col">
//                         <StudentDetails student={this.selectedStudent} /> */}
//                         <Clock/>
//                         {/* <FormDemo fostu={this.state.students}/>
//                         <ApiDemo/> */}
//                     </div>
//                 </div>
//             </div>
//         );
//     }
// }

// export default App;